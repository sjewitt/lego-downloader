from domain.domain import Config

def get():
    return Config('localhost',8080,'192.168.1.115')
